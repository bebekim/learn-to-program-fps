"""Render the lecture's small Markdown subset with distinct teaching styles."""
from pathlib import Path
import html
import re
import base64

ROOT = Path(__file__).resolve().parent.parent

def inline(value):
    value = html.escape(value)
    value = re.sub(r'`([^`]+)`', r'<code>\1</code>', value)
    value = re.sub(r'\*\*([^*]+)\*\*', r'<strong>\1</strong>', value)
    return re.sub(r'\*([^*]+)\*', r'<em>\1</em>', value)

lines = (ROOT / 'LECTURE.md').read_text().splitlines()
body = []
i = 0
while i < len(lines):
    line = lines[i]
    if line.startswith('```'):
        language = line[3:]
        code = []
        i += 1
        while i < len(lines) and lines[i] != '```':
            code.append(lines[i])
            i += 1
        kind = 'terminal' if language == 'sh' else 'cpp'
        label = 'TERMINAL · Type in Terminal' if kind == 'terminal' else 'C++ CODE · Type in your source file'
        body.append(f'<div class="code-panel {kind}"><div class="code-label">{label}</div><pre><code>{html.escape(chr(10).join(code))}</code></pre></div>')
    elif line.startswith(('**C++ CODE', '**TERMINAL')):
        pass  # The styled code panel carries this label.
    elif match := re.fullmatch(r'!\[(.*?)\]\((.*?)\)', line):
        image_path = ROOT / match[2]
        mime = 'image/svg+xml' if image_path.suffix == '.svg' else 'image/png'
        encoded = base64.b64encode(image_path.read_bytes()).decode('ascii')
        body.append(f'<figure><img src="data:{mime};base64,{encoded}" alt="{html.escape(match[1], quote=True)}"></figure>')
    elif match := re.match(r'^(#{1,3}) (.*)', line):
        level = len(match[1])
        body.append(f'<h{level}>{inline(match[2])}</h{level}>')
    elif line.startswith('- [ ] '):
        body.append(f'<p class="mission">&#9633; {inline(line[6:])}</p>')
    elif line == '---':
        body.append('<hr>')
    elif line.strip():
        body.append(f'<p>{inline(line)}</p>')
    i += 1

style = '''
:root { color-scheme: light; }
* { box-sizing: border-box; }
body { margin: 0; background: #f3f5f8; color: #243247; font: 19px/1.65 system-ui, sans-serif; }
main { max-width: 1040px; margin: 32px auto; padding: 36px 48px; background: white; border-radius: 18px; }
h1 { font-size: 38px; line-height: 1.2; } h2 { margin-top: 56px; padding-top: 24px; border-top: 2px solid #e5ebf2; line-height: 1.3; }
p { margin: 18px 0; } p code { padding: 2px 6px; border-radius: 4px; background: #e8edf5; color: #17354a; }
figure { margin: 24px 0; padding: 10px; background: #eff8ff; border: 2px solid #c9e5f6; border-radius: 12px; overflow-x: auto; }
img { display: block; max-width: 100%; height: auto; }
.code-panel { margin: 24px 0; border-radius: 12px; overflow: hidden; border: 2px solid; }
.cpp { background: #172b4d; color: #f5f8ff; border-color: #365e99; }
.terminal { background: #103d33; color: #e1fff1; border-color: #287c60; }
.code-label { padding: 10px 18px; font: 700 14px/1.5 system-ui, sans-serif; letter-spacing: .04em; }
.cpp .code-label { background: #294776; } .terminal .code-label { background: #1b5947; }
pre { margin: 0; padding: 22px; overflow-x: auto; font: 17px/1.7 Menlo, Consolas, monospace; tab-size: 4; }
.mission { margin: 8px 0; }
@media(max-width: 650px) { main { margin: 0; padding: 24px 16px; } h1 { font-size: 30px; } pre { font-size: 14px; } }
@media print { body, main { margin: 0; padding: 0; } * { print-color-adjust: exact; -webkit-print-color-adjust: exact; } .code-panel, figure { break-inside: avoid; } }
'''
output = '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Learn to program an FPS</title><style>' + style + '</style></head><body><main>' + '\n'.join(body) + '</main></body></html>'
(ROOT / 'LECTURE.html').write_text(output)
print('Rendered LECTURE.html')
