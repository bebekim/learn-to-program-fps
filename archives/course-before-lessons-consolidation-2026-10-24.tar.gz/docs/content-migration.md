# Consolidation into edu/learn-to-program-fps

The `edu` course is the canonical teaching project. Its 24 lessons, instructor answers,
starter/target programs, Windows workflow, raylib project, and checkpoint verifier are preserved.

Imported from the former `game/learn-to-program-fps` workspace:

- Visual C++ primer, including object files and linking, now in `lectures/00-visual-cpp-primer.md`.
- Inline diagrams added to 12 relevant lessons without replacing their practice or answers.
- Corrected Emacs/Pandoc/Mermaid browser-preview instructions and code shading.
- Root `LECTURE.md` as a short entry point to the merged course.

Earlier standalone HTML previews, raster/SVG experiments, patches, and the old renderer
are historical artifacts, not the current teaching path. A complete pre-migration
snapshot is retained in `archives/game-workspace-before-merge.tar.gz` for recovery.
The source folder is retained until the merged destination has been checked.

The teaching sequence is explicitly CommandLineFPS → Javidx9 upgraded FPS → raylib → Unreal. The showcase page precedes the primer and links each of the first three destinations to a demo.
