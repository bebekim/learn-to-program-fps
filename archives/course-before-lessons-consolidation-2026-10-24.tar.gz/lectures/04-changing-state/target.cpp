#include <iostream>

int main()
{
    int moves = 0;
    std::cout << "Before: " << moves << "\n";
    // Teacher comparison: intended change shown here.
    moves = moves + 2;
    std::cout << "After: " << moves << "\n";
    moves = moves + 1;
    std::cout << "After another move: " << moves << "\n";
    return 0;
}
