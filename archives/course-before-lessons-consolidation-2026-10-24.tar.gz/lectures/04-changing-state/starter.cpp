#include <iostream>

int main()
{
    int moves = 0;
    std::cout << "Before: " << moves << "\n";
    // TRY THIS: make this update add two instead of one.
    moves = moves + 1;
    std::cout << "After: " << moves << "\n";
    moves = moves + 1;
    std::cout << "After another move: " << moves << "\n";
    return 0;
}
