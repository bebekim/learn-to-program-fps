#include <iostream>

int main()
{
    char command = '?';
    // Teacher comparison: intended change shown here.
    std::cout << "Type one letter, then press Enter: ";
    if (!(std::cin >> command)) return 0; // Adult-supplied end-of-input handling.
    std::cout << "You typed: " << command << "\n";
    return 0;
}
