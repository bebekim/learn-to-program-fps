#include <iostream>

int main()
{
    // TRY THIS: print the title before the map.
    std::cout << "#####\n";
    std::cout << "#...#\n";
    std::cout << "#####\n";
    std::cout << "Nathan's Maze\n";
    return 0;
}
