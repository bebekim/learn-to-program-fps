#include <iostream>

int main()
{
    // Teacher comparison: intended change shown here.
    std::cout << "Nathan's Maze\n";
    std::cout << "#####\n";
    std::cout << "#...#\n";
    std::cout << "#####\n";
    return 0;
}
