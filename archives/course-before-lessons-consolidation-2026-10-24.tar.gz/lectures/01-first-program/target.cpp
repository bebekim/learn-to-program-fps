#include <iostream>

int main()
{
    // Teacher comparison: intended change shown here.
    std::cout << "The Hidden Maze\n";
    std::cout << "Find the exit.\n";
    return 0;
}
