#include <iostream>

int main()
{
    // TRY THIS: make the title your own.
    std::cout << "Nathan's Maze\n";
    std::cout << "Find the exit.\n";
    return 0;
}

