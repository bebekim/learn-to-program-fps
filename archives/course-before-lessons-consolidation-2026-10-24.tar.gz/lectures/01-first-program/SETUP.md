# Adult setup for lecture 01

Use Geany to edit starter.cpp. Geany is an editor; verify a compiler separately.
This exercise needs only the C++ standard library. Do not configure the repository's
raylib CMake project for it.

With Developer PowerShell for VS 2022, from this lecture folder:

```powershell
cl /nologo /EHsc /std:c++17 /W4 starter.cpp /Fe:maze.exe
.\maze.exe
```

Or, if an adult has already installed and verified g++ on PATH:

```powershell
g++ -std=c++17 -Wall -Wextra -Wpedantic starter.cpp -o maze.exe
.\maze.exe
```

Choose one compiler path. Do not install a second toolchain just for this lesson.
After every source edit, compile again and run only after compilation succeeds.
An old executable can remain after a failed compile; check the success result.
Have the adult configure Geany's build command for the chosen compiler once.

On the adult Mac, from this lecture folder:

```sh
c++ -std=c++17 -Wall -Wextra -Wpedantic starter.cpp -o /tmp/nathan-maze
/tmp/nathan-maze
```

A successful Mac run verifies this portable starter only, not Nathan's Windows
compiler installation or Geany configuration.

