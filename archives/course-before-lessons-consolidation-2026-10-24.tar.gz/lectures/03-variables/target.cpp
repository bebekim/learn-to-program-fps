#include <iostream>

int main()
{
    // Teacher comparison: intended change shown here.
    int health = 8;
    std::cout << "Health: " << health << "\n";
    std::cout << "Remembered health: " << health << "\n";
    return 0;
}
