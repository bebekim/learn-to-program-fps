#include <iostream>

int main()
{
    // TRY THIS: choose a different starting health.
    int health = 5;
    std::cout << "Health: " << health << "\n";
    std::cout << "Remembered health: " << health << "\n";
    return 0;
}
