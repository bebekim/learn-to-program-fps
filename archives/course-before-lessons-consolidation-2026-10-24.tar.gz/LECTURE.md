# Nathan’s C++ workshop

First [see where we’re going](lectures/00-see-the-destination.md): **CommandLineFPS → Javidx9 → raylib → Unreal**.

Then start with the [visual C++ primer](lectures/00-visual-cpp-primer.md), then follow [the 24-lesson course](lectures/README.md).

The primer explains compilation, object files, and linking with boxes and arrows. Use only the part that matches today’s lesson.

[Emacs browser-preview setup](docs/emacs-markdown-preview.md) enables Mermaid diagrams and shaded code blocks.
