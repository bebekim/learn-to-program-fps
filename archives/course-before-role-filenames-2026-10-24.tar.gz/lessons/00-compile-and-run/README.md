# 00 — Compile and run a C++ program

**For:** Nathan with an adult. **When:** during the learning session.
**Purpose:** learn how source code becomes a program and practise building/running it.

**Adult: before the session**, complete [SETUP.md](SETUP.md) once to install and verify
the tools. Then return here. **Nathan: start below; the installation guide is not
part of today's lesson.**

**Mission:** turn a supplied C++ source file into a runnable program and show its
message on screen. No programming knowledge is assumed. Allow 20–30 minutes after
the adult has installed and verified the compiler.

Geany is the editor; clang++, g++, or cl is the compiler driver. Use the toolchain
already prepared for this computer. All of today's explanations and exercises are
in this README; you do not need to switch back to SETUP.md.

## 1. Follow the chart

This is the write → build → run chart from our [visual guide](../VISUAL-GUIDE.md):

```mermaid
flowchart TD
    A["SOURCE FILE: hello.cpp"] -->|"BUILD: compile and link"| B["EXECUTABLE: hello on Mac; hello.exe on Windows"]
    B -->|"RUN the executable"| C["OUTPUT: Hello, maze explorer!"]
```

Point to each box before typing a command:

- **Source:** text instructions saved in a .cpp file.
- **Build:** translate and connect the instructions and required library code.
- **Executable:** the resulting program that the operating system can run.
- **Run:** execute that program and observe what it does.

Saving is not building, and building is not running. A program can build successfully
without having been run yet.

## 2. Open the supplied source

Open [hello.cpp](hello.cpp) in Geany. Do not type terminal commands inside the source file.

**C++ CODE — already supplied in hello.cpp:**

```cpp
#include <iostream>

int main()
{
    std::cout << "Hello, maze explorer!\n";
    return 0;
}
```

Today, use the surrounding lines as supplied packaging. Point to the message in
quotes and predict the output. The \n requests a new line. Detailed language syntax
comes later.

## 3. Find the source file in a terminal

On the adult **Mac**, open Terminal:

```sh
cd "$HOME/repositories/edu/learn-to-program-fps/lessons/00-compile-and-run"
pwd
ls
```

On Nathan's **Windows PC**, open PowerShell. This example assumes the course was
copied to source inside his user folder; substitute the actual path:

```powershell
cd "$HOME\source\learn-to-program-fps\lessons\00-compile-and-run"
Get-Location
Get-ChildItem
```

Both listings should show hello.cpp. If it is missing, correct the directory before
building. A Mac path beginning /Users is not Nathan's Windows path.

## 4. Build, then run

Use **one** of the following platform sections. Only run after a successful build.

### Mac — Clang

**TERMINAL — build:**

```sh
clang++ -std=c++17 -Wall -Wextra -Wpedantic hello.cpp -o hello
```

The compiler may print nothing on success. Look for the new executable:

```sh
ls -l hello
```

**TERMINAL — run:**

```sh
./hello
```

### Windows — GCC after MSYS2 setup

**POWERSHELL — build:**

```powershell
g++ -std=c++17 -Wall -Wextra -Wpedantic hello.cpp -o hello.exe
```

**POWERSHELL — run, only if the build succeeded:**

```powershell
.\hello.exe
```

### Windows alternative — existing MSVC

If the adult prepared MSVC, use its **Developer PowerShell** instead of GCC.
Build:

```powershell
cl /nologo /EHsc /std:c++17 /W4 hello.cpp /Fe:hello.exe
```

Run only after the build succeeds:

```powershell
.\hello.exe
```

**Expected output on either platform:**

```text
Hello, maze explorer!
```

The program ends after printing. That is the intended behaviour.

## 5. Read the command instead of memorising it

```mermaid
flowchart TD
    A["clang++ hello.cpp -o hello"] --> B["clang++: choose the C++ compiler driver"]
    A --> C["hello.cpp: read this source file"]
    A --> D["-o hello: name the executable"]
    E["./hello"] --> F["Run hello from the current directory"]
```

Read the actual command as a request to a program:

```sh
clang++ -std=c++17 -Wall -Wextra -Wpedantic hello.cpp -o hello
```

The terminal starts clang++ and passes the remaining words to it as arguments.
Words beginning with a dash are options: they tell the tool how to do its job.

| Part | What we are asking for |
| --- | --- |
| clang++ | Start Clang's C++ driver: the tool that coordinates compiling and linking |
| -std=c++17 | Interpret the source using the C++17 language rules |
| -Wall | Enable a useful group of warnings about suspicious code; despite its name, not every possible warning |
| -Wextra | Enable additional warnings beyond the Wall group |
| -Wpedantic | Request diagnostics for certain uses outside the selected language standard |
| hello.cpp | Read this source file from the current directory |
| -o hello | Write the result to a file named hello; -o takes the following word as its output name |

These options are instructions to the build tool, not lines of C++ to put in
hello.cpp. C++17 is a version of the language, not a different compiler to install.

### What happened after you pressed Enter?

1. **Read and prepare the source.** Clang reads hello.cpp. Preprocessing handles
   directives such as #include <iostream>, making the relevant declarations available.
   Including a header does not mean copying the whole library implementation into
   our source file.
2. **Check and translate.** The compiler checks the source against the selected
   language/type rules and translates it towards machine instructions for the target
   computer. The requested warning groups help report some suspicious constructs.
3. **Produce a compiled piece.** Assembly produces object code for our program.
   This one-command build handles intermediate output for us; it does not normally
   leave a separate hello.o alongside hello.cpp.
4. **Link the program.** The driver invokes the linker to connect the compiled
   piece with startup code and required libraries, including C++ standard-library
   support used by std::cout. Libraries need not all be copied into the executable;
   some are loaded when the program runs.
5. **Write hello.** If the build succeeds, we now have an executable named hello
   in this directory. The source file remains source text. This command does not
   execute the new program.

For the unchanged greeting, a successful build will usually return to the prompt
without printing anything. The greeting appears only after the separate run command:

```sh
./hello
```

The ./ means “in the current directory.” The operating system loads the executable,
its startup code leads to main, and our output instruction prints the greeting.

### Predict the difference

Ask: “What changes if we replace -o hello with -o maze?” The new output file is
named maze, so run ./maze. The greeting is unchanged because its source has not
changed. An older hello file, if present, remains a separate executable.

Ask: “What if we omit the warning options?” They request diagnostics, not gameplay
behaviour. For this valid tiny program, the intended output is unchanged, but we
have asked for fewer warnings. Warnings help us inspect code; a warning-free build
does not prove the game behaves as intended. An error normally prevents a successful
build; a warning alone is not necessarily a failure.

Instructor answer in one sentence: “We asked Clang to build hello.cpp using C++17,
with useful diagnostics, and save the runnable result as hello; we have not run it yet.”

After the one-command build is comfortable, use the more detailed chart:

```mermaid
flowchart TD
    A["hello.cpp: source"] -->|"COMPILE: -c"| B["hello.o: object file"]
    B -->|"LINK with required library code"| C["hello: executable"]
    C -->|"RUN"| D["Message on screen"]
```

An object file is a built piece, not normally a program you can run by itself.
The one-command build handles the intermediate stage for us. Splitting the build
into two commands is an optional learning experiment, after the first build works.
On Mac, from this lesson's directory:

```sh
clang++ -std=c++17 -Wall -Wextra -Wpedantic -c hello.cpp -o hello.o
clang++ hello.o -o hello
```

The first command compiles only (-c); the second links. After both succeed, run
./hello. The result should print the same greeting. Return to the one-command
build for ordinary work.

## 6. Practise the workflow

1. Predict the message before running the supplied program.
2. Build it. Point to the source file and the resulting executable.
3. Run it. Compare the output with the prediction.
4. Run it again without rebuilding. The source has not changed, so the same output
   is expected.
5. Ask: “If we edit the source tomorrow, will this old executable change by itself?”
   Predict that another build will be needed. Lesson 01 makes that change.

Keep compilation and execution as separate actions initially so Nathan can explain
which command does which job.

## Checkpoint and instructor answers

Nathan is ready for lesson 01 when he can:

- Find hello.cpp and say that it contains source text.
- Build with the supplied command and identify the executable it produces.
- Run the executable from the terminal and recognise the expected output.
- Explain that editing source requires rebuilding before a new program can be run.

Listen for “save → build → run”, not “Geany runs my text automatically.”
If a build fails, stop and read the first useful error; do not run an older executable
as evidence that the new source works. If the file cannot be found, inspect the
directory rather than changing correct C++ code.

Do not quiz him on every flag or header. Today's understanding is the transformation
from instructions to executable to observable behaviour.

Next: [01 — Run, change, run again](../01-first-program/README.md), where Nathan
changes the game's messages and checks the rebuilt result.
