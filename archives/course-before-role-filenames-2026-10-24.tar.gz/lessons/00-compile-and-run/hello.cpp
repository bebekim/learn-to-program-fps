#include <iostream>

int main()
{
    std::cout << "Hello, maze explorer!\n";
    return 0;
}
