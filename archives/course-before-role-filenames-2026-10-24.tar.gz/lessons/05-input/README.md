# 05 — Ask the player

CLI foundations. Work in short sessions; a lesson is a learning unit, not one uninterrupted talk.

## Before you begin

04: values and assignment.

Files: [starter.cpp](starter.cpp) is the runnable starting point.
Keep [target.cpp](target.cpp) for the adult's comparison after the attempt.
The starter runs before any edits; its TRY THIS comment identifies the initial small change.

Use [the common compile/run instructions](../SETUP.md). Copy into Nathan's active
working file rather than overwriting his previous work. Do not ask him to retype
the whole supplied program.

## Explain it together

Output tells the player something. **Input** lets the running program receive a value from the player. Today the program asks for one character and repeats it back; it does not yet act on the command.

`char command = '?';` prepares a place for a single character. Single quotes such as 'w' describe one character; double quotes describe a text string. `std::cin >> command;` reads a character from standard input.

In the ordinary console, type the letter and press Enter. This is different from the original FPS, which polls whether a key is held.

## Worked example — predict before running

```cpp
char command = '?';
std::cout << "Type one letter: ";
std::cin >> command;
std::cout << "You typed: " << command << "\n";
```

If the player enters d, command contains 'd' and the echoed message includes d. The initial '?' is replaced by the input.

The supplied starter wraps reading in an end-of-input check. Tell Nathan: “This extra line lets our program stop safely if input ends.” It is adult-supplied plumbing, not today's exercise.

## Guided practice

1. Predict what happens if the player types w and presses Enter.
2. Run and try w.
3. Run again and type x. Does changing the input require recompiling? Explain.
4. Change the prompt to say that one letter and Enter are required.
5. Compare changing an instruction, which needs a rebuild, with supplying new input, which does not.

## Independent challenge

Choose another prompt that asks for one letter. Keep the echo so that the player can see what was received. Do not try a full player name with a char variable.

Ask for a prediction before execution. Offer one hint at a time; do not reveal the
target as the answer to the independent challenge.

## Understanding checkpoint

Nathan distinguishes changing source from changing input and can explain the value that gets echoed.

Record three short entries: **My rule; My prediction; What happened.** Save a working
copy and stop before introducing another idea if the explanation is still uncertain.

---

## Instructor answers and troubleshooting

The prompt does not itself store a command. Reading input updates command. Enter is normally needed before the console supplies the line.

With formatted char input, whitespace is skipped. If the player types several letters, one is consumed by this read and the rest remain available; do not call this a full-line parser. Use single-letter examples now.

If the learner expects w to move a player, ask where the movement instruction is. Input alone does not invent behaviour.

### What the comparison target demonstrates

The target improves only the prompt; the echo behaviour is unchanged.

### Source connection

A: line 140, `GetAsyncKeyState`; typed input is a new bridge and requires Enter.

A/B/C resolve to exact local filenames in [the reference index](../references.md).
These are teacher references, not student reading prerequisites. The supplied lesson
examples are original small teaching programs; they do not copy the reference's
Windows engine infrastructure.

Next: [06 — Choose an action](../06-conditions/README.md)

